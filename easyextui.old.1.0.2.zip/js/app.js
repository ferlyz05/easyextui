var db = window.openDatabase('ndiing', '1.0', '', 5 * 1024 * 1024);

db.transaction(function(e) {
});